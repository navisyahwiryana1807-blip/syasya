A LITTLE GIFT FOR YOU ♡

Cara menjalankan:
1. Ekstrak ZIP ini.
2. Buka folder digital_gift_website.
3. Klik dua kali index.html untuk melihat website di browser.
4. Untuk mengunggah: buka https://app.netlify.com/drop lalu seret folder digital_gift_website (atau ZIP hasil ekstrak yang berisi index.html di root) ke halaman Netlify Drop.
5. Setelah deploy, Netlify akan memberi URL website yang bisa dibagikan.

Cara mengubah surat:
- Buka index.html dengan Notepad atau VS Code.
- Cari teks surat di bagian <p id="letterBody"> ... </p>, lalu ganti dengan suratmu.
- Ganti 'Dear, you' dengan nama penerima melalui teks id="recipientHeading".
- Ganti 'someone who cares about you' dengan namamu.
- Untuk tombol link di halaman terakhir, cari id="specialLink". Hapus class="hidden", lalu ganti href="#" dengan URL tujuan yang kamu punya.
- Untuk mengganti emoji kenangan dengan foto, bagian kartu kenangan menggunakan .photo-placeholder. Kamu bisa mengganti isi emoji dengan tag gambar, misalnya <img src="foto1.jpg" alt="Kenangan" style="width:100%;height:100%;object-fit:cover"> dan letakkan foto di folder yang sama.

Catatan:
- Musik saat ini berupa nada lembut sederhana yang dibuat browser, bukan lagu berhak cipta. Musik perlu ditekan oleh pengguna untuk aktif.
- Website ini belum dipublikasikan otomatis. Kamu perlu mengunggahnya ke Netlify untuk memperoleh link publik.
